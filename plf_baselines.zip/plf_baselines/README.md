# Two probabilistic load-forecasting baselines on spain / ercot / elia

Self-contained. Two entry points, one per model; both read the JSON config for a dataset,
build features from the CSV it names, fit, and write a scored table for the test period.

| model | paper | entry | what it outputs |
|---|---|---|---|
| **CRPS-LOP** (density combination) | Li, Wang & Zhang 2020, IEEE TSG 11(2):1679-1690 | `train_bench_density.py` | Gaussian mixture of 15 base learners, weights minimise CRPS |
| **iQRNN** | Zhang, Quan & Srinivasan 2019, IEEE TSG 10(4):4425-4434 | `train_bench_iqrnn.py` | one MLP -> the three quantiles directly, pinball loss |

Both forecast the quantiles {0.05, 0.50, 0.95} of every step of the next calendar day from a
lookback window ending at the dataset's deadline hour. Everything about the protocol (day
set, lookback window, standardisation, metrics) is shared between the two.

## Setup

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt

Python 3.10+. CPU is enough; torch is only used by iQRNN and the CPU build is fine.

Put the three cleaned CSVs in `data/quantile/` (see the README there), or edit `csv_path` in
`data/quantile/{spain,ercot,elia}_config.json`. Nothing else in the configs needs changing.

Check the environment and data before spending time on a fit:

    PYTHONPATH=. python test/test_bench_density.py

It reads all three CSVs and asserts, among other things, that the usable day counts come out
to spain 869/292/291, ercot 416/142/140, elia 2239/748/746. If that line fails, the data or the
config is not what the code expects; nothing downstream will be comparable.

## Run

Always from this directory, with `PYTHONPATH=.`.

    export PYTHONPATH=.
    export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1   # density only, see below

    # CRPS-LOP: 15 base models in a process pool, 3 seeds, mean +- sd
    python -u train_bench_density.py --dataset spain --seeds 0 1 2 --workers 8
    python -u train_bench_density.py --dataset ercot --seeds 0 1 2 --workers 8
    python -u train_bench_density.py --dataset elia  --seeds 0 1 2 --workers 8

    # iQRNN: feature selection once (cached), then 3 seeds
    python -u train_bench_iqrnn.py --dataset spain --seeds 0 1 2
    python -u train_bench_iqrnn.py --dataset ercot --seeds 0 1 2
    python -u train_bench_iqrnn.py --dataset elia  --seeds 0 1 2

Threads: the density script runs its 15 base models in parallel and pins BLAS to one thread
inside each worker, so set the `*_NUM_THREADS=1` variables and give it `--workers` = cores.
The iQRNN script trains one network at a time and wants the opposite: leave the thread
variables unset (or set them to the core count) so torch and the RFE forest use all cores.

Useful flags:

    train_bench_density.py   --models XGB1 NN1 GPR1    subset of the 15 (needs >= 2)
    train_bench_iqrnn.py     --spec bQRNN-400          the paper's own control network
                             --n-features N            override the RFE target
                             --device cuda             GPU for the network (RFE stays on CPU)
                             --refresh-rfe             recompute the cached feature selection

`slurm/` holds the two array scripts used on our cluster; the `--account` / `--qos` lines are
ours and will need changing.

## Runtime, roughly

The density script is dominated by its five Gaussian-process members (about 14 min each on
our nodes, independent of dataset size because they subsample 2000 rows). With 8 workers,
expect about 1.5 h per dataset for 3 seeds. iQRNN is minutes per seed on spain/ercot and
under 15 min per seed on elia; the one-off feature selection adds a few minutes.

## Output

    results/bench/{dataset}/density/
        test_scores.csv                mean and sd over seeds, 4 weighting schemes x 10 metrics
        per_seed_scores.csv            every seed's scores
        weights_and_base_models.csv    the 15 weights + each base model's CRPS on T2 and T4
        test_quantiles.npz             actual, timestamps, levels, (mean, sd), quantile curves

    results/bench/{dataset}/iqrnn/
        test_scores.csv, per_seed_scores.csv, test_quantiles.npz, features.json (RFE cache)

In `density/test_scores.csv` the row to report is **CRPS-guided**: that is the paper's method.
The other three (MAPE-guided, Simple average, Best individual) are the comparison schemes the
paper itself reports.

## Metrics and units

Reported: Pinball, PICP, MPIW, Winkler, MAE, RMSE, MSE, MAPE, SMAPE (and CRPS for the density
model). The target is z-scored with the mean and sd of the **training days**, and Pinball,
MPIW, Winkler, MAE, RMSE, MSE are in those units. PICP is printed as a percentage (nominal 90).
MAPE and SMAPE are computed in physical units, because the z-scored target crosses zero.

Standard deviations are the sample sd over seeds (`ddof=1`). A seed re-seeds the whole
pipeline (GPR subsamples, network initialisation, booster subsampling, QP multistart), not
just one component. iQRNN's feature selection is deliberately not re-seeded: the paper selects
features once and trains repeatedly.

## Protocol, in one paragraph

A target day is used only if all its steps exist, the whole lookback window before its
deadline exists, and the whole day lies inside the split's date range. Every lag `k` (in steps,
counted back from a target step) must satisfy `G + H - 1 <= k <= L - 1 + G`, where `H` is
steps per day (24 or 96), `L` the lookback in steps (168 or 672), and `G` the steps from the
deadline to the day's first step (spain 1, ercot 15, elia 4). That gives lag windows of
[24, 168], [38, 182] and [99, 675]. Lags below the floor would read data after the deadline;
lags above the ceiling would read before the window starts.

CRPS-LOP uses the paper's 11 lags (24,25,26,27,28,48,72,96,120,144,168 h), shifted by whole
days to clear the floor and clipped to the ceiling: 11 on spain, 10 on ercot and elia. Plus
hour, day-of-week, month, weekend. No exogenous variables (the paper's choice).

iQRNN uses every target lag in the window, daily echoes of the other observed columns
(`actual_cols`), the day-ahead forecast columns (`forecast_cols`) at lag 0, and calendar
features; recursive feature elimination keeps min(100, pool/3) of them. Batch size is one
week of steps (168 hourly, 672 quarter-hourly).

## Layout

    train_bench_density.py, train_bench_iqrnn.py   entries
    src/bench/       data.py (dataset, day set, splits), metrics.py, density.py, iqrnn.py,
                     base_models.py (the 15 density base learners)
    src/density/     combine.py (the QP), crps_gmm.py (closed-form mixture CRPS), gaussfit.py
    src/qrnn/        model.py (network, pinball loss, training schedule)
    src/quantile/    qeval.py (CRPS from quantiles), _pool.py (process pool)
    test/            contract tests
    data/quantile/   the three configs; CSVs go here
