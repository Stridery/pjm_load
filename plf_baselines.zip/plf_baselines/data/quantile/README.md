Put the three cleaned CSVs here, with exactly these names (they are what `csv_path` in the
three JSON configs points at):

    cleaned_spain_data.csv
    ercot_data_cleaned.csv
    cleaned_elia_data.csv

Or edit `csv_path` in each `*_config.json` to wherever the files live. The other fields in
the configs (column classes, split dates, deadline hour, lookback) are read as-is.
