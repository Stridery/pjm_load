import torch
import torch.nn as nn
import os
import numpy as np
import pandas as pd
from tqdm import tqdm


class PointTrainer:
	"""
	A universal Trainer for point forecasting models (Transformer, FFNN, ArchFormer, etc.).
	"""

	def __init__(
		self,
		model,
		train_loader,
		train_eval_loader,
		val_loader,
		test_loader,
		criterion,
		optimizer,
		device="cpu",
		means=None,
		stds=None,
		target_col=None,
	):
		self.model = model.to(device)
		self.train_loader = train_loader
		self.train_eval_loader = train_eval_loader
		self.val_loader = val_loader
		self.test_loader = test_loader
		self.criterion = criterion
		self.optimizer = optimizer
		self.device = device
		self.means = means
		self.stds = stds
		self.target_col = target_col

	# ====================== #
	# ===== Training ======= #
	# ====================== #
	def train(self, num_epochs=50, save_path="./results/best_model.pth"):
		best_val_loss = float("inf")

		for epoch in range(num_epochs):
			self.model.train()
			total_loss = 0.0

			loop = tqdm(self.train_loader, desc=f"Epoch {epoch + 1}/{num_epochs}", leave=False)
			for X, y in loop:
				X, y = X.to(self.device), y.to(self.device)

				self.optimizer.zero_grad()
				pred = self.model(X)
				loss = self.criterion(pred, y)
				loss.backward()
				self.optimizer.step()

				total_loss += loss.item()
				loop.set_postfix(train_loss=loss.item())

			avg_train_loss = total_loss / len(self.train_loader)
			val_loss = self.evaluate(self.val_loader)

			print(f"Epoch [{epoch + 1}/{num_epochs}] Train={avg_train_loss:.4f} | Val={val_loss:.4f}")

			if val_loss < best_val_loss:
				best_val_loss = val_loss
				# self.save_model(save_path)
				# print(f"New best model saved at {save_path}")

	# ====================== #
	# ===== Evaluation ===== #
	# ====================== #
	def evaluate(self, data_loader):
		self.model.eval()
		running_loss = 0.0
		with torch.no_grad():
			for X, y in data_loader:
				X, y = X.to(self.device), y.to(self.device)
				pred = self.model(X)
				loss = self.criterion(pred, y)
				running_loss += loss.item()
		return running_loss / len(data_loader)

	def test(self):
		print("\nEvaluating on Test Set...")
		test_loss = self.evaluate(self.test_loader)
		print(f"Final Test Loss: {test_loss:.6f}")
		return test_loss

	# ====================== #
	# ===== I/O Helpers ==== #
	# ====================== #
	def save_model(self, save_path):
		os.makedirs(os.path.dirname(save_path), exist_ok=True)
		torch.save(self.model.state_dict(), save_path)

	def load_model(self, load_path):
		if os.path.exists(load_path):
			self.model.load_state_dict(torch.load(load_path, map_location=self.device))
			print(f"Model loaded from {load_path}")
		else:
			print(f"Model file not found: {load_path}")

	# ====================== #
	# ===== Prediction ===== #
	# ====================== #
	def predict_and_save(self, df_train_index, df_val_index, df_test_index, dataset="all", save_path="./results/predictions.csv"):
		self.model.eval()

		def predict_on_loader(loader, index):
			all_preds, all_actuals = [], []
			all_preds_scaled, all_actuals_scaled = [], []

			with torch.no_grad():
				for X, y in loader:
					X = X.to(self.device)
					pred = self.model(X)

					all_preds_scaled.append(pred.cpu().numpy())
					all_actuals_scaled.append(y.cpu().numpy())

					if self.stds is not None and self.means is not None and self.target_col is not None:
						pred_rescaled = pred.cpu().numpy() * self.stds[self.target_col] + self.means[self.target_col]
						actual_rescaled = y.cpu().numpy() * self.stds[self.target_col] + self.means[self.target_col]
					else:
						pred_rescaled = pred.cpu().numpy()
						actual_rescaled = y.cpu().numpy()

					all_preds.append(pred_rescaled)
					all_actuals.append(actual_rescaled)

			df = pd.DataFrame({
				"ACTUAL": np.concatenate(all_actuals).flatten(),
				"PREDICTED": np.concatenate(all_preds).flatten(),
				"ACTUAL_SCALED": np.concatenate(all_actuals_scaled).flatten(),
				"PREDICTED_SCALED": np.concatenate(all_preds_scaled).flatten(),
			}, index=index)

			return df

		df_train = predict_on_loader(self.train_eval_loader, df_train_index)
		df_val = predict_on_loader(self.val_loader, df_val_index)
		df_test = predict_on_loader(self.test_loader, df_test_index)

		# df_all = pd.concat([df_train, df_val, df_test])
		# os.makedirs(os.path.dirname(save_path), exist_ok=True)
		# df_all.to_csv(save_path)
		# print(f"Predictions saved to {save_path}")

	def predict_in_memory(self, loader):
		self.model.eval()
		all_y_true, all_y_pred = [], []
		with torch.no_grad():
			for X, y in loader:
				X, y = X.to(self.device), y.to(self.device)
				output = self.model(X)
				# 若模型返回 (y_hat, sigma_sq)，只取第一个
				if isinstance(output, tuple):
					y_hat = output[0]
				else:
					y_hat = output
				all_y_true.append(y.cpu())
				all_y_pred.append(y_hat.cpu())
		return torch.cat(all_y_true), torch.cat(all_y_pred)
