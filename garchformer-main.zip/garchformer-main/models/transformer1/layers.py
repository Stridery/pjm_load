import torch
import torch.nn as nn
import math

"""First Implement the Encoder Part"""

"""Sinusoidal positional encoding"""
class PositionalEncoding(nn.Module):
	"""Applies sinusoidal positional encoding to embed time information."""
	def __init__(self, seq_length, d_emb):
		super().__init__()
		pe = torch.zeros(seq_length, d_emb)
		position = torch.arange(0, seq_length, dtype=torch.float).unsqueeze(1)
		div_term = torch.exp(torch.arange(0, d_emb, 2).float() * (-math.log(10000.0) / d_emb))
		pe[:, 0::2] = torch.sin(position * div_term)
		pe[:, 1::2] = torch.cos(position * div_term)
		self.register_buffer('positional_encoding', pe)

	def forward(self, x):
		return x + self.positional_encoding


class SparseSelfAttention(nn.Module):
	"""Implements Sparse Multihead Self-Attention (Big Bird style)."""
	def __init__(self, d_emb, num_heads, seq_length, sparsity_ratio=0.2):
		super().__init__()
		self.W_q_enc = nn.Linear(d_emb, d_emb)  # Query transform
		self.W_k_enc = nn.Linear(d_emb, d_emb)  # Key transform
		self.W_v_enc = nn.Linear(d_emb, d_emb)  # Value transform
		self.attn = nn.MultiheadAttention(embed_dim=d_emb, num_heads=num_heads, batch_first=True)
		self.sparsity_ratio = sparsity_ratio
		self.seq_length = seq_length

	def forward(self, x):
		batch_size, seq_length, d_emb = x.shape

		# Compute Q, K, V
		Q = self.W_q_enc(x)
		K = self.W_k_enc(x)
		V = self.W_v_enc(x)

		# Generate Big Bird Sparse Attention Mask
		mask = torch.zeros(seq_length, seq_length, device=x.device)
		window_size = int(seq_length * self.sparsity_ratio)
		for i in range(seq_length):
			start = max(0, i - window_size)
			end = min(seq_length, i + window_size)
			mask[i, start:end] = 1  # Allow attention within local window
		mask = mask.bool()

		# Compute Attention
		attn_output, _ = self.attn(Q, K, V, attn_mask=mask)
		return attn_output


class FeedForwardBlock(nn.Module):
	"""Feedforward network for Transformer (used in both Encoder and Decoder)."""
	def __init__(self, d_emb, expansion=4, dropout=0.1):
		super().__init__()
		self.fc1 = nn.Linear(d_emb, expansion * d_emb)  # Expand embedding dimension
		self.activation = nn.GELU()  # GELU activation
		self.dropout1 = nn.Dropout(dropout)
		self.fc2 = nn.Linear(expansion * d_emb, d_emb)  # Project back to d_emb
		self.dropout2 = nn.Dropout(dropout)

	def forward(self, x):
		x = self.fc1(x)  # Expand
		x = self.activation(x)
		x = self.dropout1(x)
		x = self.fc2(x)  # Project back
		return self.dropout2(x)



class EncoderLayer(nn.Module):
	"""Single Transformer Encoder Layer with Sparse Attention."""
	def __init__(self, d_emb, num_heads, seq_length, dropout=0.1, sparsity_ratio=0.1):
		super().__init__()
		self.attn = SparseSelfAttention(d_emb, num_heads, seq_length, sparsity_ratio)  # Pass sparsity ratio
		self.norm1 = nn.LayerNorm(d_emb)
		self.ffn = FeedForwardBlock(d_emb)
		self.norm2 = nn.LayerNorm(d_emb)

	"""Post-Norm"""
	# def forward(self, x):
	# 	attn_output = self.attn(x)
	# 	x = x + attn_output  # Residual connection
	# 	x = self.norm1(x)  # Apply LayerNorm directly
	#
	# 	ffn_output = self.ffn(x)
	# 	x = x + ffn_output
	# 	x = self.norm2(x)  # Apply LayerNorm directly
	#
	# 	return x

	"""Pre-Norm"""

	def forward(self, x):
		x = self.norm1(x)  # Pre-Norm before attention
		attn_output = self.attn(x)
		x = x + attn_output  # Residual connection 1

		x = self.norm2(x)  # Pre-Norm before FFN
		ffn_output = self.ffn(x)
		x = x + ffn_output  # Residual connection 2

		return x


class Encoder(nn.Module):
	"""Full Transformer Encoder with multiple Encoder Layers."""
	def __init__(self, num_layers, seq_length, num_features, d_emb, num_heads, dropout=0.1, sparsity_ratio=0.1):
		super().__init__()
		self.input_projection = nn.Linear(num_features, d_emb)  # Project input features to d_emb
		self.pos_encoding = PositionalEncoding(seq_length, d_emb)
		self.layers = nn.ModuleList([
			EncoderLayer(d_emb, num_heads, seq_length, dropout, sparsity_ratio) for _ in range(num_layers)
		])

	def forward(self, x):
		x = self.input_projection(x)
		x = self.pos_encoding(x)

		for layer in self.layers:
			x = layer(x)

		return x


"""Next we implement the Decoder part"""
class DecoderLayer(nn.Module):
	"""Single Transformer Decoder Layer with Self-Attention and Cross-Attention."""
	def __init__(self, d_emb, num_heads, seq_length_dec, seq_length_enc, dropout=0.1):
		super().__init__()

		self.W_q_dec = nn.Linear(d_emb, d_emb)
		self.W_k_dec = nn.Linear(d_emb, d_emb)
		self.W_v_dec = nn.Linear(d_emb, d_emb)

		self.W_q_cross = nn.Linear(d_emb, d_emb)
		self.W_k_cross = nn.Linear(d_emb, d_emb)
		self.W_v_cross = nn.Linear(d_emb, d_emb)

		self.self_attn = nn.MultiheadAttention(embed_dim=d_emb, num_heads=num_heads, batch_first=True)
		self.cross_attn = nn.MultiheadAttention(embed_dim=d_emb, num_heads=num_heads, batch_first=True)

		self.ffn = FeedForwardBlock(d_emb)

		self.norm1 = nn.LayerNorm(d_emb)  # Replaced BatchNorm1d with LayerNorm
		self.norm2 = nn.LayerNorm(d_emb)  # Replaced BatchNorm1d with LayerNorm
		self.norm3 = nn.LayerNorm(d_emb)  # Replaced BatchNorm1d with LayerNorm

	def forward(self, x, enc_output):
		batch_size, seq_length_dec, d_emb = x.shape

		Q = self.W_q_dec(x)
		K = self.W_k_dec(x)
		V = self.W_v_dec(x)

		attn_mask = torch.triu(torch.ones(seq_length_dec, seq_length_dec, device=x.device), diagonal=1).bool()

		self_attn_output, _ = self.self_attn(Q, K, V, attn_mask=attn_mask)
		x = x + self_attn_output
		x = self.norm1(x)  # Apply LayerNorm directly

		Q_cross = self.W_q_cross(x)
		K_cross = self.W_k_cross(enc_output)
		V_cross = self.W_v_cross(enc_output)

		cross_attn_output, _ = self.cross_attn(Q_cross, K_cross, V_cross)
		x = x + cross_attn_output
		x = self.norm2(x)  # Apply LayerNorm directly

		# ffn_output = self.ffn(x)
		# x = x + ffn_output
		# x = self.norm3(x)  # Apply LayerNorm directly

		# 改
		x = self.ffn(x)

		return x

class Decoder(nn.Module):
	"""Full Transformer Decoder with multiple Decoder Layers."""

	def __init__(self, num_layers, seq_length_dec, seq_length_enc, d_emb, num_heads, dropout=0.1):
		super().__init__()
		self.layers = nn.ModuleList([
			DecoderLayer(d_emb, num_heads, seq_length_dec, seq_length_enc, dropout) for _ in range(num_layers)
		])

		# Final projection layer to map decoder output to the desired prediction dimension
		self.output_projection = nn.Linear(d_emb, 1)  # Predict single value per timestep (e.g., netload)

	def forward(self, x, enc_output):
		for layer in self.layers:
			x = layer(x, enc_output)  # Pass through multiple decoder layers

		x = self.output_projection(x)  # Project to final output dimension (batch_size, 24, 1)
		return x  # (batch_size, 24, 1)

""" Testing the Encoder"""
if __name__ == "__main__":
	# Define test parameters
	batch_size = 32
	seq_length_enc = 168  # Encoder sequence length (historical data)
	seq_length_dec = 24   # Decoder sequence length (forecast horizon)
	num_features = 10      # Input features
	d_emb = 64           # Transformer embedding dimension
	num_heads = 4        # Number of attention heads
	num_layers = 1       # Number of encoder & decoder layers
	dropout = 0.1        # Dropout rate

	# Generate random input data for the encoder
	encoder_input = torch.randn(batch_size, seq_length_enc, num_features)  # Simulated raw input for encoder

	# Initialize the Encoder
	encoder = Encoder(num_layers, seq_length_enc, num_features, d_emb, num_heads, dropout)

	# Pass input through the Encoder
	encoder_output = encoder(encoder_input)  # Shape: (batch_size, seq_length_enc, d_emb)

	# Generate random input data for the decoder
	decoder_input = torch.randn(batch_size, seq_length_dec, d_emb)  # Simulated decoder input

	# Initialize the Decoder
	decoder = Decoder(num_layers, seq_length_dec, seq_length_enc, d_emb, num_heads, dropout)

	# Run the decoder
	decoder_output = decoder(decoder_input, encoder_output)

	# Print shape results
	print(f"Encoder input shape: {encoder_input.shape}")    # Expected: (32, 168, 8)
	print(f"Encoder output shape: {encoder_output.shape}")  # Expected: (32, 168, 64)
	print(f"Decoder input shape: {decoder_input.shape}")    # Expected: (32, 24, 64)
	print(f"Decoder output shape: {decoder_output.shape}")  # Expected: (32, 24, 1)

	# === Step 8: Fair Comparison ===
	def count_parameters(model):
		return sum(p.numel() for p in model.parameters() if p.requires_grad)


	total_params = count_parameters(encoder) + count_parameters(decoder)

	print(f"\nTotal trainable parameters in this configuration: {total_params:,}")
	print(f" - Encoder: {count_parameters(encoder):,}")
	print(f" - Decoder: {count_parameters(decoder):,}")
	print(f"   (Decoder includes final output projection)")












