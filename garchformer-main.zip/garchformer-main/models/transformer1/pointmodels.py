import torch
import torch.nn as nn
import math
import sys
import os
from models.transformer1.layers import Encoder, Decoder


class MLPConnectionBlock(nn.Module):
    """
    4-layer MLP block that transforms the encoder output
    to match the decoder input shape.
    """

    def __init__(self, seq_length_enc, seq_length_dec, d_emb, intermediate_dim=32):
        """
        Args:
            seq_length_enc (int): Encoder sequence length.
            seq_length_dec (int): Decoder sequence length.
            d_emb (int): Embedding dimension.
            intermediate_dim (int): Hidden intermediate temporal size (M).
        """
        super().__init__()

        self.fc1 = nn.Linear(d_emb, 1)  # Step 1: Reduce embedding dim (batch, seq_length_enc, 1)
        self.fc2 = nn.Linear(seq_length_enc, intermediate_dim)  # Step 2: Expand temporal axis (batch, M, 1)
        self.activation = nn.GELU()  # Activation function
        self.fc3 = nn.Linear(intermediate_dim, seq_length_dec)  # Step 3: Map to output length (batch, seq_length_dec, 1)
        self.fc4 = nn.Linear(1, d_emb)  # Step 4: Restore embedding dimension (batch, seq_length_dec, d_emb)

    def forward(self, x):
        """
        Forward pass through the MLP block.
        """
        # print(f"MLP Block Input Shape: {x.shape}")  # Expecting (batch, 168, 64)
        x = self.fc1(x)  # (batch, 168, 1)
        # print(f"MLP Block Shape after fc1: {x.shape}")
        x = x.permute(0, 2, 1)  # (batch, 1, 168) for correct transformation
        x = self.fc2(x)  # (batch, 1, M)
        # print(f"MLP Block Shape after fc2: {x.shape}")
        x = self.activation(x)  # Activation
        # print(f"MLP Block Shape after activation: {x.shape}")
        x = self.fc3(x)  # (batch, 1, 24)
        # print(f"MLP Block Shape after fc3: {x.shape}")
        x = x.permute(0, 2, 1)  # (batch, 24, 1) back to normal
        x = self.fc4(x)  # (batch, 24, d_emb)
        # print(f"MLP Block Output Shape: {x.shape}")  # Expecting (batch, 24, 64)
        return x


class Transformer(nn.Module):
    """
    Transformer Model integrating Encoder, MLP Connection Block, and Decoder.
    """

    def __init__(self, num_layers_enc, num_layers_dec, seq_length_enc, seq_length_dec, num_features, d_emb,
                 num_heads_enc, num_heads_dec, dropout=0.1, intermediate_dim=32):
        """
        Args:
            num_layers_enc (int): Number of encoder layers.
            num_layers_dec (int): Number of decoder layers.
            seq_length_enc (int): Encoder sequence length.
            seq_length_dec (int): Decoder sequence length.
            num_features (int): Number of input features.
            d_emb (int): Shared embedding dimension.
            num_heads_enc (int): Attention heads in encoder.
            num_heads_dec (int): Attention heads in decoder.
            dropout (float): Dropout rate.
            intermediate_dim (int): Internal hidden size for MLP block.
        """
        super().__init__()

        # **Encoder**
        self.encoder = Encoder(num_layers_enc, seq_length_enc, num_features, d_emb, num_heads_enc, dropout)

        # **MLP Connection Block**
        self.connection_block = MLPConnectionBlock(seq_length_enc, seq_length_dec, d_emb, intermediate_dim)

        # **Decoder**
        self.decoder = Decoder(num_layers_dec, seq_length_dec, seq_length_enc, d_emb, num_heads_dec, dropout)

    def forward(self, x):
        """
        Forward Pass
        Args:
            x (Tensor): Input data of shape **(batch_size, seq_length_enc, num_features)**.

        Returns:
            Tensor: Forecast output of shape **(batch_size, seq_length_dec, 1)**.
        """
        # print(f"Transformer Input Shape: {x.shape}")  # (batch_size, 168, 8)

        # **Step 1: Encode Input**
        encoder_output = self.encoder(x)  # Shape: (batch_size, 168, 64)
        # print(f"Encoder Output Shape: {encoder_output.shape}")

        # **Step 2: MLP Connection Block**
        decoder_input = self.connection_block(encoder_output)  # Shape: (batch_size, 24, 64)
        # print(f"Decoder Input Shape After MLP Connection: {decoder_input.shape}")

        # **Step 3: Decode**
        forecast_output = self.decoder(decoder_input, encoder_output)  # Shape: (batch_size, 24, 1)
        # print(f"Final Transformer Output Shape: {forecast_output.shape}")

        return forecast_output.squeeze(-1)  # Shape: (batch_size, 24)


""" Testing the Transformer Model"""
if __name__ == "__main__":
    # Define test parameters
    batch_size = 32
    seq_length_enc = 168  # Encoder sequence length (historical data)
    seq_length_dec = 24  # Decoder sequence length (forecast horizon)
    num_features = 8  # Input features
    d_emb = 64  # Transformer embedding dimension
    num_heads_enc = 8  # Number of attention heads in the encoder
    num_heads_dec = 4  # Number of attention heads in the decoder (now different from encoder!)
    num_layers_enc = 4  # Number of encoder layers
    num_layers_dec = 2  # Number of decoder layers (now different from encoder!)
    dropout = 0.1  # Dropout rate

    # Generate random input data
    transformer_input = torch.randn(batch_size, seq_length_enc, num_features)  # Simulated raw input

    # Initialize the Transformer model
    transformer = Transformer(num_layers_enc, num_layers_dec, seq_length_enc, seq_length_dec,
                              num_features, d_emb, num_heads_enc, num_heads_dec, dropout)

    # Run the transformer model
    transformer_output = transformer(transformer_input)

    # Print shape results
    print(f"Transformer input shape: {transformer_input.shape}")  # Expected: (32, 168, 8)
    print(f"Transformer output shape: {transformer_output.shape}")  # Expected: (32, 24)
