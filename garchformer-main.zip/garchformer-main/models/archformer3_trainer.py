import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from models.base_trainer import PointTrainer


class ArchFormer3Trainer(PointTrainer):
	"""
	Trainer for ArchFormer3:
	Adds a variance-consistency loss term to align σ² with (y - ŷ)².
	Structure identical to PointTrainer, but loss = MSE + λ * L1(σ², (y - ŷ)²)
	"""

	def __init__(self, *args, lambda_cons=0.1, **kwargs):
		"""
		Args:
			lambda_cons (float): weight for variance consistency term.
		"""
		super().__init__(*args, **kwargs)
		self.lambda_cons = lambda_cons

	# ====================== #
	# ===== Training ======= #
	# ====================== #
	def train(self, num_epochs=50, save_path="./results/best_model.pth"):
		best_val_loss = float("inf")

		for epoch in range(num_epochs):
			self.model.train()
			total_loss, total_pred_loss, total_cons_loss = 0.0, 0.0, 0.0

			loop = tqdm(self.train_loader, desc=f"Epoch {epoch + 1}/{num_epochs}", leave=False)
			for X, y in loop:
				X, y = X.to(self.device), y.to(self.device)

				self.optimizer.zero_grad()

				# === Model forward ===
				output = self.model(X)

				# Some ArchFormer variants return tuple (y_hat, sigma_sq)
				if isinstance(output, tuple):
					y_hat, sigma_sq = output
				else:
					y_hat, sigma_sq = output, None

				# print("DEBUG | Model output type:", type(output),
				# 	  "len=", len(output) if isinstance(output, tuple) else 1)

				# === Primary loss ===
				loss_pred = self.criterion(y_hat, y)

				# === Variance consistency loss (if sigma_sq available) ===
				if sigma_sq is not None:
					# print("σ² mean:", sigma_sq.mean().item(), "std:", sigma_sq.std().item())
					eps_sq = (y - y_hat) ** 2
					loss_cons = F.l1_loss(sigma_sq, eps_sq)
					loss = loss_pred + self.lambda_cons * loss_cons
				else:
					loss_cons = torch.tensor(0.0, device=self.device)
					loss = loss_pred

				loss.backward()
				self.optimizer.step()

				total_loss += loss.item()
				total_pred_loss += loss_pred.item()
				total_cons_loss += loss_cons.item()

				loop.set_postfix(
					train_loss=f"{loss.item():.4f}",
					pred_loss=f"{loss_pred.item():.4f}",
					cons_loss=f"{loss_cons.item():.4f}"
				)

			avg_train_loss = total_loss / len(self.train_loader)
			avg_pred_loss = total_pred_loss / len(self.train_loader)
			avg_cons_loss = total_cons_loss / len(self.train_loader)

			val_loss = self.evaluate(self.val_loader)

			# print(
			# 	f"Epoch [{epoch + 1}/{num_epochs}] "
			# 	f"Train={avg_train_loss:.4f} | Pred={avg_pred_loss:.4f} | Cons={avg_cons_loss:.4f} | Val={val_loss:.4f}"
			# )

			if val_loss < best_val_loss:
				best_val_loss = val_loss
				# self.save_model(save_path)
				# print(f"New best model saved at {save_path}")

	# ====================== #
	# ===== Evaluation ===== #
	# ====================== #
	def evaluate(self, data_loader):
		self.model.eval()
		running_loss, running_pred_loss, running_cons_loss = 0.0, 0.0, 0.0

		with torch.no_grad():
			for X, y in data_loader:
				X, y = X.to(self.device), y.to(self.device)

				output = self.model(X)
				if isinstance(output, tuple):
					y_hat, sigma_sq = output
				else:
					y_hat, sigma_sq = output, None

				loss_pred = self.criterion(y_hat, y)

				if sigma_sq is not None:
					eps_sq = (y - y_hat) ** 2
					loss_cons = F.l1_loss(sigma_sq, eps_sq)
					loss = loss_pred + self.lambda_cons * loss_cons
				else:
					loss_cons = torch.tensor(0.0, device=self.device)
					loss = loss_pred

				running_loss += loss.item()
				running_pred_loss += loss_pred.item()
				running_cons_loss += loss_cons.item()

		avg_loss = running_loss / len(data_loader)
		avg_pred = running_pred_loss / len(data_loader)
		avg_cons = running_cons_loss / len(data_loader)

		# print(f"Val Loss={avg_loss:.4f} (Pred={avg_pred:.4f}, Cons={avg_cons:.4f})")
		return avg_loss
