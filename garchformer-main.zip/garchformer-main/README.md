# GARCHFormer

Transformer-based models for day-ahead electricity load forecasting, with a focus on volatility-aware architectures (GARCHFormer family).

## Models

The repository implements several point-forecasting models under a unified training pipeline:

- `archformer2`, `archformer3` — GARCHFormer variants
- `transformer1` — vanilla Transformer baseline
- `lstm`, `lstmattlstm`, `ffnn`, `fgnn` — non-Transformer baselines

## Installation

Python 3.8+ is recommended.

```bash
git clone git@github.com:MoyiGuo/garchformer.git
cd garchformer
python -m venv venv
source venv/bin/activate          # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Quick Start

A small synthetic dataset (`tmp_synth_bc_like.csv`, 5 months hourly load + weather) is included in `data/public_cleaned_data/` for sanity-checking the pipeline.

Run ARCHFormer3 on this dataset:

```bash
python run_point_forecast.py \
    --data_cfg tmp_synth_bc_like_config.json \
    --param_cfg archformer3.json
```

Outputs (training log, predictions, runtime summary) are written to:

```
results/point_forecast/<model_name>/<dataset_name>/
```

## Configuration

The pipeline is driven by two JSON configs:

- **Data config** (`cfgs_data/*.json`) — specifies CSV path, target column, feature columns, train/val/test date ranges, lookback length, and forecast horizon.
- **Model config** (`cfgs_grid_search/*.json`) — specifies model class, hyperparameter grid, learning rate, and number of epochs.

Available data configs include `tmp_synth_bc_like_config.json`, `pjm_config.json`, `spain_config.json`, `france_config.json`, and several others.

To run a different model on a different dataset, simply pair the corresponding configs:

```bash
python run_point_forecast.py \
    --data_cfg <data_config>.json \
    --param_cfg <model_config>.json
```

## Repository Structure

```
garchformer/
├── cfgs_data/                  # dataset configurations (JSON)
├── cfgs_grid_search/           # model + hyperparameter configurations (JSON)
├── data/public_cleaned_data/   # input CSVs (sample data only on GitHub)
├── models/                     # model implementations
│   ├── archformer2/
│   ├── archformer3/
│   ├── transformer1/
│   ├── ffnn/
│   ├── archformer3_trainer.py
│   └── base_trainer.py
├── utils/                      # data loading, training, metrics, I/O
├── results/                    # generated at runtime (gitignored)
├── run_point_forecast.py       # main entry point
└── requirements.txt
```

## Notes

- Datasets are not committed to the repository (`data/` is gitignored). The included `tmp_synth_bc_like.csv` is a small synthetic sample for testing the pipeline.
- The `results/` directory is generated automatically when you run training.
- All times in configs are in UTC unless otherwise noted in the dataset config file.

## Contact

Moyi Guo — moyi@gatech.edu
