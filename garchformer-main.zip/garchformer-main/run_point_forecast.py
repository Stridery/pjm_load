"""
Author: Moyi Guo
Create Date: Oct 16, 2025
---------------------
run_point_forecast.py
---------------------
Main entry point for point forecasting experiments.
- Reads dataset configs from `cfgs_data/`
- Loads hyperparameter configs from `cfgs_grid_search/`
- Initializes model and data loaders
- Supports multiple architectures (Transformer, GARCHFormer)

Usage:
    python run_point_forecast.py --data_cfg tmp_synth_bc_like_config.json --param_cfg transformer1.json
	
"""
import argparse
from datetime import datetime
import json
import numpy as np
import os
import pandas as pd
import time
import torch

from utils.io_utils import setup_environment, dynamic_import_class, setup_output_paths
from utils.metrics_utils import calculate_metrics
from utils.analysis_utils import analyze_load_rolling
from utils.seed_utils import set_seed
from utils.training_utils import prepare_model_and_trainer
from utils.experiment_utils import generate_valid_param_combinations, record_experiment_result


if __name__ == "__main__":
	args, data_cfg, param_cfg, df_scaled, means, stds, stats = setup_environment(analyze=False)

	paths = setup_output_paths(param_cfg, data_cfg)
	# result_path = paths["result_path"]
	# save_model_path = paths["save_model_path"]
	# save_csv_path = paths["save_csv_path"]

	# --- Load Model and Trainer dynamically ---
	model_name = param_cfg["model_name"].lower()
	class_name = param_cfg["class_name"]
	trainer_class_name = param_cfg.get("trainer_class", "PointTrainer")
	model_module = f"models.{model_name}.pointmodels"
	if model_name == "archformer3":
		trainer_module = "models.archformer3_trainer"
	else:
		trainer_module = "models.base_trainer"
	ModelClass = dynamic_import_class(model_module, class_name)
	TrainerClass = dynamic_import_class(trainer_module, trainer_class_name)


	# --- Generate hyperparameter combinations ---
	valid_configs, param_keys = generate_valid_param_combinations(param_cfg, data_cfg, paths["result_path"])

	# === Training & Evaluation Phase ===
	print(f"Starting training for {len(valid_configs)} valid configurations...")
	device = "cuda" if torch.cuda.is_available() else "cpu"
	print(f"Using device: {device}")

	# Ensure result directory exists
	os.makedirs(os.path.dirname(paths["result_path"]), exist_ok=True)

	# Record the starting time of training
	start_time = time.time()
	start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

	for i, config in enumerate(valid_configs):
		trainer, model, loaders, tensors = prepare_model_and_trainer(
			config=config,
			data_cfg=data_cfg,
			param_cfg=param_cfg,
			ModelClass=ModelClass,
			TrainerClass=TrainerClass,
			df_scaled=df_scaled,
			means=means,
			stds=stds,
			device=device,
			batch_size=32
		)

		print(f"Training configuration {i + 1}/{len(valid_configs)}: {config}")

		# === Train + Evaluate ===
		trainer.train(num_epochs=param_cfg.get("epochs", 50), save_path=None)
		trainer.test()

		# === Predict (in-memory, no CSV write) ===
		y_true, y_pred = trainer.predict_in_memory(loaders["test"])

		metrics = calculate_metrics(y_true=y_true, y_pred=y_pred, means=means, stds=stds, target_col=data_cfg["target_col"])
		print(f"[{model_name.upper()}] Config {i + 1}/{len(valid_configs)}: Metrics = {metrics}")

		record_experiment_result(paths["result_path"], param_keys, config, metrics, data_cfg)

	# --- After all configs finished ---
	end_time = time.time()
	end_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

	total_minutes = (end_time - start_time) / 60
	avg_minutes = total_minutes / max(len(valid_configs), 1)

	runtime_log = os.path.join(os.path.dirname(paths["result_path"]), "runtime_summary.txt")
	with open(runtime_log, "w") as f:
		f.write(f"Experiment Start: {start_timestamp}\n")
		f.write(f"Experiment End:   {end_timestamp}\n")
		f.write(f"Total Runtime:    {total_minutes:.2f} minutes\n")
		f.write(f"Avg per Config:   {avg_minutes:.2f} minutes\n")
		f.write(f"Total Configs:    {len(valid_configs)}\n")

	print("\n=== Runtime Summary ===")
	print(f"Experiment Start: {start_timestamp}")
	print(f"Experiment End:   {end_timestamp}")
	print(f"Total Runtime:    {total_minutes:.2f} minutes")
	print(f"Avg per Config:   {avg_minutes:.2f} minutes")
	print(f"Total Configs:    {len(valid_configs)}")
	print(f"Summary saved to: {runtime_log}")










