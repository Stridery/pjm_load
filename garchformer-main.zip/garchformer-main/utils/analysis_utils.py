import pandas as pd
import matplotlib.pyplot as plt

def analyze_load_rolling(df, load_cols=None, window_days=7, plot=True):
    """
    Analyze rolling 7-day hourly mean and std for load data,
    and compute correlation between rolling mean and std.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with DatetimeIndex and load columns.
    load_cols : list[str], optional
        Column(s) to analyze. Defaults to all columns containing 'load'.
    window_days : int, optional
        Rolling window in days (default=7).
    plot : bool, optional
        Whether to plot mean/std/scatter.

    Returns
    -------
    corr : float
        Correlation between rolling mean and std for the first load column.
    rolling_mean_last : pd.DataFrame
        Last 7 days rolling mean.
    rolling_std_last : pd.DataFrame
        Last 7 days rolling std.
    """

    df = df.copy()
    df.index = pd.to_datetime(df.index)

    if load_cols is None:
        load_cols = [c for c in df.columns if "load" in c.lower()]

    hours_per_day = 24
    window_size = window_days * hours_per_day

    rolling_mean = pd.DataFrame(index=df.index, columns=load_cols)
    rolling_std = pd.DataFrame(index=df.index, columns=load_cols)

    # Rolling mean/std per hour
    for h in range(24):
        hour_mask = df.index.hour == h
        df_hour = df[load_cols][hour_mask]
        rolling_mean.loc[hour_mask] = df_hour.rolling(window=window_days, min_periods=1).mean().values
        rolling_std.loc[hour_mask] = df_hour.rolling(window=window_days, min_periods=1).std().values

    df_last_week = df.iloc[-window_size:]
    rolling_mean_last = rolling_mean.loc[df_last_week.index]
    rolling_std_last = rolling_std.loc[df_last_week.index]

    # Quantify relationship
    mean_series = rolling_mean_last[load_cols[0]].astype(float).squeeze()
    std_series = rolling_std_last[load_cols[0]].astype(float).squeeze()
    corr = mean_series.corr(std_series)

    if plot:
        plt.figure(figsize=(12, 4))
        plt.plot(rolling_mean_last.index, mean_series, label=f"{load_cols[0]} mean")
        plt.title(f"Rolling {window_days}-day hourly mean (last {window_days} days)")
        plt.xlabel("Time"); plt.ylabel("Load"); plt.legend(); plt.tight_layout(); plt.show()

        plt.figure(figsize=(12, 4))
        plt.plot(rolling_std_last.index, std_series, label=f"{load_cols[0]} std")
        plt.title(f"Rolling {window_days}-day hourly std (last {window_days} days)")
        plt.xlabel("Time"); plt.ylabel("Std of load"); plt.legend(); plt.tight_layout(); plt.show()

        plt.figure(figsize=(5, 4))
        plt.scatter(mean_series, std_series, alpha=0.6)
        plt.xlabel("Rolling mean"); plt.ylabel("Rolling std")
        plt.title(f"Mean–Std relationship (r={corr:.2f})")
        plt.tight_layout(); plt.show()

    print(f"Correlation between rolling mean and std (last {window_days} days): {corr:.3f}")
    return corr, rolling_mean_last, rolling_std_last
