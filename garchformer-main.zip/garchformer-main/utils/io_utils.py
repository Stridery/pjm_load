import argparse
import json
import os
import pandas as pd
import importlib
from utils.seed_utils import set_seed
from utils.data_utils import standardize_data_new, prepare_dataloaders
from utils.analysis_utils import analyze_load_rolling


def setup_environment(default_seed=700, batch_size=32, analyze=True):
	"""
	Set up full experiment environment:
	- Parse command-line arguments
	- Load JSON configs
	- Load and standardize dataset
	- Optionally analyze rolling load pattern
	- Prepare dataloaders and tensors

	Returns:
		args, data_cfg, param_cfg, df_scaled, stats, loaders, tensors
	"""
	# --- 1. Set seed ---
	set_seed(default_seed)

	# --- 2. Parse arguments ---
	parser = argparse.ArgumentParser()
	parser.add_argument('--data_cfg', type=str, required=True)
	parser.add_argument('--param_cfg', type=str, required=True)
	args = parser.parse_args()

	# --- 3. Load config files ---
	data_cfg_file = f"cfgs_data/{args.data_cfg}"
	param_cfg_file = f"cfgs_grid_search/{args.param_cfg}"
	data_cfg = load_json(data_cfg_file)
	param_cfg = load_json(param_cfg_file)

	# --- 4. Load and standardize dataset ---
	df = pd.read_csv(data_cfg["csv_path"], parse_dates=True, index_col=0)
	df_scaled, means, stds, df_train, df_val, df_test = standardize_data_new(df, data_cfg)

	# --- 5. Analyze (optional) ---
	stats = None
	if analyze:
		corr, rolling_mean_last, rolling_std_last = analyze_load_rolling(
			df_scaled, load_cols=["total load actual"], plot=False
		)
		stats = {"corr": corr}

	# # --- 6. Prepare dataloaders ---
	# loaders, tensors = prepare_dataloaders(df_scaled, data_cfg, batch_size=batch_size)

	return args, data_cfg, param_cfg, df_scaled, means, stds, stats



def setup_output_paths(param_cfg, data_cfg):
	"""
	Set up and create all necessary output directories and file paths.

	Args:
		param_cfg (dict): Parameter configuration dictionary containing 'model_name' and 'base_result_dir'.
		data_cfg (dict): Data configuration dictionary containing 'dataset_name'.

	Returns:
		dict: Dictionary containing key paths like result_path, save_model_path, save_csv_path, base_dir.
	"""
	model_name = param_cfg["model_name"]
	dataset_name = data_cfg["dataset_name"]

	# Base directory: results/model/dataset/
	base_dir = os.path.join(param_cfg["base_result_dir"], model_name, dataset_name)
	os.makedirs(base_dir, exist_ok=True)

	paths = {
		"base_dir": base_dir,
		"result_path": os.path.join(base_dir, "grid_results.csv"),
		"save_model_path": os.path.join(base_dir, "best_model.pth"),
		"save_csv_path": os.path.join(base_dir, "point_output.csv")
	}
	return paths

def load_json(path):
	"""Load a JSON file into a Python dictionary."""
	if not os.path.exists(path):
		raise FileNotFoundError(f"Config file not found: {path}")
	try:
		with open(path, 'r') as f:
			return json.load(f)
	except json.JSONDecodeError as e:
		raise ValueError(f"Invalid JSON format in file {path}: {e}")

def dynamic_import_class(module_name, class_name):
	module = importlib.import_module(module_name)
	return getattr(module, class_name)