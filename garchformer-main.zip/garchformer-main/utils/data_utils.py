import pandas as pd
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
from datetime import datetime, timedelta


def standardize_data_new(df, data_cfg):
	"""
	Standardize selected columns based on training period statistics.

	Args:
		df (pd.DataFrame): Raw dataframe with datetime index.
		data_cfg (dict): Contains date splits and selected columns.

	Returns:
		tuple:
			- df_scaled (pd.DataFrame): Standardized dataframe.
			- means (pd.Series): Mean of training data.
			- stds (pd.Series): Std of training data.
			- df_train (pd.DataFrame)
			- df_val (pd.DataFrame)
			- df_test (pd.DataFrame)
	"""

	# --- Convert config date strings to datetime
	train_start = pd.to_datetime(data_cfg["train_start"])
	train_end = pd.to_datetime(data_cfg["train_end"])
	val_start = pd.to_datetime(data_cfg["val_start"])
	val_end = pd.to_datetime(data_cfg["val_end"])
	test_start = pd.to_datetime(data_cfg["test_start"])
	test_end = pd.to_datetime(data_cfg["test_end"])

	# --- Pick columns to standardize (actual + forecast)
	std_cols = data_cfg["actual_cols"] + data_cfg["forecast_cols"]

	# --- 1. Get training portion for computing mean/std
	df_train = df.loc[train_start:train_end, std_cols].copy()
	means = df_train.mean()
	stds = df_train.std().replace(0, 1e-8)

	# --- 2. Apply normalization to full dataset
	df_scaled = df.copy()
	df_scaled[std_cols] = (df_scaled[std_cols] - means) / stds

	# --- 3. Extract subsets
	df_val = df_scaled.loc[val_start:val_end]
	df_test = df_scaled.loc[test_start:test_end]

	return df_scaled, means, stds, df_train, df_val, df_test


def generate_samples_new(df_scaled, data_cfg, start_key, end_key):
	"""
	Generic sample generation function for any dataset with arbitrary time granularity.

	Args:
		df_scaled: standardized dataframe with datetime index
		data_cfg: dictionary containing dataset-specific configuration
		start_key, end_key: keys in data_cfg to determine date ranges

	Returns:
		samples_X: list of X tensors (lookback_steps, num_features)
		samples_y: list of y tensors (forecast_steps,)
		sample_times: list of datetime forecast time indices (flattened)
	"""
	actual_cols = data_cfg['actual_cols']
	forecast_cols = data_cfg['forecast_cols']
	aux_cols = data_cfg['aux_cols']
	target_col = data_cfg['target_col']

	granularity_minutes = data_cfg.get("granularity_minutes", 60)
	granularity = timedelta(minutes=granularity_minutes)

	lookback_steps = data_cfg["lookback_hours"] * 60 // granularity_minutes
	forecast_steps = data_cfg["forecast_hours"] * 60 // granularity_minutes
	deadline_step = data_cfg["forecast_deadline_hour"] * 60 // granularity_minutes
	step_per_day = 1440 // granularity_minutes

	start_time = pd.to_datetime(data_cfg[start_key])
	end_time = pd.to_datetime(data_cfg[end_key])

	samples_X, samples_y, sample_times = [], [], []
	current_time = start_time

	while current_time + (forecast_steps - 1) * granularity <= end_time:
		# y: forecast window
		y_window = df_scaled.loc[current_time : current_time + granularity * (forecast_steps - 1)]
		if len(y_window) < forecast_steps:
			current_time += granularity * step_per_day
			continue
		y_tensor = torch.tensor(y_window[target_col].values, dtype=torch.float32)

		# X: lookback window ending at deadline
		lookback_end = current_time - granularity * (step_per_day - deadline_step)
		lookback_start = lookback_end - granularity * (lookback_steps - 1)
		X_window = df_scaled.loc[lookback_start : lookback_end]
		if len(X_window) < lookback_steps:
			current_time += granularity * step_per_day
			continue

		select_cols = actual_cols + forecast_cols + aux_cols
		X_tensor = torch.tensor(X_window[select_cols].values, dtype=torch.float32)

		samples_X.append(X_tensor)
		samples_y.append(y_tensor)

		# Expanded forecast times
		expanded_times = [current_time + i * granularity for i in range(forecast_steps)]
		sample_times.extend(expanded_times)

		# ---- DEBUG ----
		expected_len = lookback_steps
		actual_len = X_tensor.shape[0]

		if actual_len != expected_len:
			# 若 current_time 已经是 tz-aware，就直接 tz_convert；
			# 否则先 tz_localize 再 tz_convert
			if current_time.tzinfo is None:
				ct_eastern = current_time.tz_localize("UTC").tz_convert("US/Eastern")
			else:
				ct_eastern = current_time.tz_convert("US/Eastern")

			print(
				f"[DEBUG] current_time={current_time}  "
				f"expected={expected_len}  got={actual_len}  "
				f"DST? {ct_eastern}"
			)
		# ---------------

		current_time += granularity * step_per_day

	return samples_X, samples_y, sample_times



def prepare_dataloaders(df_scaled, data_cfg, batch_size=32, shuffle_train=True):
	"""
	Generate train/val/test tensors and dataloaders from scaled dataframe.
	"""
	def _gen_split(start_key, end_key):
		X, y, times = generate_samples_new(df_scaled, data_cfg, start_key, end_key)
		return torch.stack(X, dim=0), torch.stack(y, dim=0), times

	X_train, y_train, train_times = _gen_split("train_start", "train_end")
	X_val, y_val, val_times = _gen_split("val_start", "val_end")
	X_test, y_test, test_times = _gen_split("test_start", "test_end")

	def _make_loader(X, y, shuffle=False):
		dataset = torch.utils.data.TensorDataset(X, y)
		return torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)

	loaders = {
		"train": _make_loader(X_train, y_train, shuffle=shuffle_train),
		"train_eval": _make_loader(X_train, y_train, shuffle=False),
		"val": _make_loader(X_val, y_val),
		"test": _make_loader(X_test, y_test),
	}

	print(f"Train: X={X_train.shape}, y={y_train.shape}")
	print(f"Val:   X={X_val.shape}, y={y_val.shape}")
	print(f"Test:  X={X_test.shape}, y={y_test.shape}")

	return loaders, {
		"X_train": X_train, "y_train": y_train,
		"X_val": X_val, "y_val": y_val,
		"X_test": X_test, "y_test": y_test,
		"train_times": train_times,
		"val_times": val_times,
		"test_times": test_times,
	}