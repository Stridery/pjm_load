import os
import csv
import itertools

def generate_valid_param_combinations(param_cfg, data_cfg, result_path):
	param_grid = param_cfg.get("param_grid", {})
	param_keys = list(param_grid.keys())
	all_combos = list(itertools.product(*param_grid.values()))

	# 从 data_cfg 读取可能的多个序列长度
	lookback_vals = data_cfg.get("lookback_hours", [168])
	forecast_vals = data_cfg.get("forecast_hours", [24])
	if not isinstance(lookback_vals, list):
		lookback_vals = [lookback_vals]
	if not isinstance(forecast_vals, list):
		forecast_vals = [forecast_vals]

	all_combos = list(itertools.product(all_combos, lookback_vals, forecast_vals))

	completed_combos = set()
	temporal_keys = ["lookback_hours", "forecast_hours"]

	# --- Skip completed combos if CSV exists ---
	if os.path.exists(result_path):
		with open(result_path, mode="r") as f:
			reader = csv.DictReader(f)
			for row in reader:
				tup = tuple(
					int(row[k]) if k not in ["dropout"] else float(row[k])
					for k in param_keys + temporal_keys
					if k in row
				)
				completed_combos.add(tup)

	valid_configs = []
	for combo_full in all_combos:
		combo, lookback, forecast = combo_full
		cfg = dict(zip(param_keys, combo))
		cfg["lookback_hours"] = lookback
		cfg["forecast_hours"] = forecast

		# ---- (1) head 整除约束 ----
		if "num_heads" in cfg and "d_model" in cfg:
			if cfg["d_model"] % cfg["num_heads"] != 0:
				continue

		# ---- (2) patch_len 与 seq_length_dec 对齐 ----
		if "seq_length_dec" in cfg and "patch_len" in cfg:
			if cfg["seq_length_dec"] % cfg["patch_len"] != 0:
				continue

		tup = tuple(list(combo) + [lookback, forecast])
		if tup not in completed_combos:
			valid_configs.append(cfg)

	print(f"Found {len(valid_configs)} valid parameter × seq-length combinations.")
	return valid_configs, param_keys + ["lookback_hours", "forecast_hours"]




def record_experiment_result(result_path, param_keys, config, metrics, data_cfg):
	lookback_hours = config.get("lookback_hours", data_cfg.get("lookback_hours"))
	forecast_hours = config.get("forecast_hours", data_cfg.get("forecast_hours"))

	header = (
		param_keys
		+ ["lookback_hours", "forecast_hours"]
		+ ["MAE", "MSE", "RMSE", "MAPE", "SMAPE"]
	)

	os.makedirs(os.path.dirname(result_path), exist_ok=True)
	file_exists = os.path.exists(result_path)

	with open(result_path, mode="a", newline="") as f:
		writer = csv.writer(f)

		if not file_exists or os.stat(result_path).st_size == 0:
			writer.writerow(header)

		writer.writerow(
			[config[k] for k in param_keys]
			+ [lookback_hours, forecast_hours]
			+ [metrics[k] for k in ["MAE", "MSE", "RMSE", "MAPE", "SMAPE"]]
		)
