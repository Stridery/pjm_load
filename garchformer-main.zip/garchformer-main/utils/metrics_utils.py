import numpy as np
import pandas as pd
import torch
def calculate_metrics(pred_csv_path=None, y_true=None, y_pred=None,
                      means=None, stds=None, target_col=None,
                      test_start_time=None, test_end_time=None):
    """
    Calculate metrics in both normalized and rescaled (real MW) spaces.
    - MAE, MSE, RMSE: computed on normalized data
    - MAPE, SMAPE: computed on rescaled (de-standardized) data

    Args:
        pred_csv_path (str): optional, path to CSV with ACTUAL/PREDICTED columns
        y_true, y_pred (array or tensor): direct predictions (normalized space)
        means, stds (dict): used to unscale if provided
        target_col (str): key for target column
    """

    # === Case 1: read from CSV ===
    if pred_csv_path is not None and os.path.exists(pred_csv_path):
        df = pd.read_csv(pred_csv_path, parse_dates=True, index_col=0)
        y_true = df["ACTUAL_SCALED"].values
        y_pred = df["PREDICTED_SCALED"].values
        y_true_res = df["ACTUAL"].values
        y_pred_res = df["PREDICTED"].values

    # === Case 2: direct tensors ===
    elif y_true is not None and y_pred is not None:
        if torch.is_tensor(y_true):
            y_true = y_true.detach().cpu().numpy()
        if torch.is_tensor(y_pred):
            y_pred = y_pred.detach().cpu().numpy()

        # === Rescale if possible ===
        if means is not None and stds is not None and target_col is not None:
            mean = means[target_col]
            std = stds[target_col]
            y_true_res = y_true * std + mean
            y_pred_res = y_pred * std + mean
        else:
            y_true_res = y_true
            y_pred_res = y_pred
    else:
        raise ValueError("Must provide either pred_csv_path or (y_true, y_pred).")

    # === Metrics in normalized space ===
    mae = np.mean(np.abs(y_true - y_pred))
    mse = np.mean((y_true - y_pred) ** 2)
    rmse = np.sqrt(mse)

    # === Metrics in rescaled (real) space ===
    mask = np.abs(y_true_res) > 1e-8
    mape = np.mean(np.abs((y_true_res[mask] - y_pred_res[mask]) / y_true_res[mask])) * 100
    smape = 100 * np.mean(
        2 * np.abs(y_pred_res - y_true_res) /
        (np.abs(y_pred_res) + np.abs(y_true_res) + 1e-8)
    )

    return {
        "MAE": mae,
        "MSE": mse,
        "RMSE": rmse,
        "MAPE": mape,
        "SMAPE": smape
    }

