import torch
import torch.nn as nn
import torch.optim as optim
import os
from utils.data_utils import prepare_dataloaders

def prepare_model_and_trainer(
	config,
	data_cfg,
	param_cfg,
	ModelClass,
	TrainerClass,
	df_scaled,
	means,
	stds,
	device="cpu",
	batch_size=32,
):
	"""
	Prepare model, dataloaders, and trainer for one valid configuration.

	Args:
		config (dict): hyperparameter configuration (may include lookback/forecast hours)
		data_cfg (dict): dataset configuration
		param_cfg (dict): parameter configuration
		ModelClass (nn.Module): model class
		TrainerClass (class): trainer class
		df_scaled (pd.DataFrame): scaled dataframe
		means, stds: normalization statistics
		device (str): computation device ("cpu" or "cuda")
		batch_size (int): batch size for dataloaders

	Returns:
		trainer, model, loaders
	"""
	data_cfg["lookback_hours"] = config["lookback_hours"]
	data_cfg["forecast_hours"] = config["forecast_hours"]

# --- 1. Handle lookback & forecast sequence lengths ---
	granularity_minutes = data_cfg.get("granularity_minutes", 60)
	lookback_hours = config.get("lookback_hours", data_cfg["lookback_hours"])
	forecast_hours = config.get("forecast_hours", data_cfg["forecast_hours"])
	lookback_steps = lookback_hours * 60 // granularity_minutes
	forecast_steps = forecast_hours * 60 // granularity_minutes

	# --- 2. Rebuild dataloaders with updated lookback/forecast ---
	data_cfg_local = {**data_cfg, "lookback_hours": lookback_hours, "forecast_hours": forecast_hours}
	loaders, tensors = prepare_dataloaders(df_scaled, data_cfg_local, batch_size=batch_size)

	# --- 3. Filter model-specific kwargs ---
	model_kwargs = {k: v for k, v in config.items() if k not in ["lookback_hours", "forecast_hours"]}
	num_features = len(data_cfg["actual_cols"] + data_cfg["forecast_cols"] + data_cfg["aux_cols"])

	# --- 4. Initialize model  ---
	model_name = param_cfg["model_name"].lower()

	if model_name == "transformer":
		model = ModelClass(
			seq_length_enc=lookback_steps,
			seq_length_dec=forecast_steps,
			num_features=num_features,
			**model_kwargs
		).to(device)

	elif model_name == "transformer1":
		model = ModelClass(
			seq_length_enc=lookback_steps,
			seq_length_dec=forecast_steps,
			num_features=num_features,
			**model_kwargs
		).to(device)

	elif model_name == "archformer1":
		model = ModelClass(
			seq_length_enc=lookback_steps,
			seq_length_dec=config["seq_length_dec"],
			num_features=num_features,
			patch_len=24,
			d_model=config["d_model"],
			num_heads=config["num_heads"],
			num_encoder_layers=config["num_encoder_layers"],
			num_decoder_layers=config["num_decoder_layers"],
			intermediate_dim=config["intermediate_dim"],
			out_len=forecast_steps,
			dropout=config["dropout"]
		).to(device)

	elif model_name == "archformer2":
		model = ModelClass(
			seq_length_enc=lookback_steps,
			seq_length_dec=lookback_steps,  # 仍与 encoder 对齐
			num_features=num_features,
			patch_len=config["patch_len"],
			d_model=config["d_model"],
			num_heads=config["num_heads"],
			num_encoder_layers=config["num_encoder_layers"],
			num_decoder_layers=config["num_decoder_layers"],
			intermediate_dim=config["intermediate_dim"],
			out_len=forecast_steps,
			dropout=config["dropout"]
		).to(device)

	elif model_name == "archformer3":
		model = ModelClass(
			seq_length_enc=lookback_steps,
			seq_length_dec=lookback_steps,  # 仍与 encoder 对齐
			num_features=num_features,
			patch_len=config["patch_len"],
			d_model=config["d_model"],
			num_heads=config["num_heads"],
			num_encoder_layers=config["num_encoder_layers"],
			num_decoder_layers=config["num_decoder_layers"],
			intermediate_dim=config["intermediate_dim"],
			out_len=forecast_steps,
			dropout=config["dropout"]
		).to(device)

	# --- 5. Define loss and optimizer ---
	criterion = nn.MSELoss()
	optimizer = optim.Adam(model.parameters(), lr=param_cfg.get("lr", 0.001))

	# --- 6. Initialize trainer ---
	trainer = TrainerClass(
		model=model,
		train_loader=loaders["train"],
		train_eval_loader=loaders["train_eval"],
		val_loader=loaders["val"],
		test_loader=loaders["test"],
		criterion=criterion,
		optimizer=optimizer,
		device=device,
		means=means,
		stds=stds,
		target_col=data_cfg["target_col"],
	)

	print(
		f"[Setup] lookback={lookback_hours}h ({lookback_steps} steps), "
		f"forecast={forecast_hours}h ({forecast_steps} steps)"
	)
	print(f"    Train: X={tensors['X_train'].shape}, y={tensors['y_train'].shape}")

	return trainer, model, loaders, tensors
